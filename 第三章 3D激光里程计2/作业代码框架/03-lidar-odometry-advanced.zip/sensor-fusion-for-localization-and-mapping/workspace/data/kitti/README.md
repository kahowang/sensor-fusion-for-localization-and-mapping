# GNSS-INS-Sim Dataset

GNSS-INS-Sim data as ROS Bags存放路径

---

## 获取数据

当运行仿真工具, 产生仿真数据后, 将数据放在该目录下, 即可在Docker环境里使用
